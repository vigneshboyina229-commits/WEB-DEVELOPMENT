ShopSphere E-commerce Demo

RUN:
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, or Firefox.
3. Internet is needed for the product photos (hosted by Unsplash).

FEATURES:
- Responsive white/light pastel UI
- Animated product cards and hero image
- Search products
- Category filtering
- Sort by price, rating, and discount
- Price, rating, and sale filters
- Wishlist
- Shopping cart with quantity controls and totals
- Promotional code copy interaction
- Newsletter demo and checkout placeholder

IMPORTANT:
This is a front-end demo. Cart state is kept in memory and resets on page refresh.
The checkout, account, and newsletter actions are demonstrations only. To take real orders,
connect a backend/API and payment provider; never collect card details directly in this static page.
